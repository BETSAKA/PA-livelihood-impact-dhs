# Load necessary libraries
library(dplyr)
library(tidyverse)
library(mapme.biodiversity)
library(terra)
library(tidyterra)
library(geodata)
library(sf)
library(progressr)
#library(rstac)
library(httr)
library(wdpar)
library(tmap)
library(pbapply)


dynamic_wdpa_vect <- vect("./data/source/WDPA_data/dynamic_wdpa.gpkg") %>%
  # Keep Terrestrial and mixed
  dplyr::filter(MARINE %in% 0:1) %>%
  # "Complexe des  AP Ambohimirahavavy Marivorahona" does not have a STATUS_YR, we set it to 2015 as per WDPA website: https://protectedareas.mg/fr/landscape/show/79?geoShapeFilterField=location&location=48.727807188419%2C-14.2119746670021%2C49.0930733591917%2C-14.2119746670021%2C49.0930733591917%2C-13.734131335043%2C48.727807188419%2C-13.734131335043%2C48.727807188419%2C-14.2119746670021&max=8&mediaFilter=no_of_images%2Cno_of_videos%2Cno_of_audio&offset=0&sort=created_on&view=stats
  mutate(
    STATUS_YR_DYN = case_when(
      WDPAID == 555697871 ~ 2015,
      STATUS == "Proposed" ~ 2026,
      TRUE ~ as.integer(STATUS_YR)
    ),
    WDPAID = as.integer(WDPAID)
  ) %>%
  # remove RAMSAR, see https://github.com/BETSAKA/PA-impact-on-deforestation/issues/46
  filter(DESIG != "Ramsar Site, Wetland of International Importance") %>%
  filter(STATUS != "Inscribed") %>%
  select(WDPAID, NAME, DESIG, MANG_AUTH, IUCN_CAT, STATUS, STATUS_YR_DYN, zone_type)

### Load Prioritaire protected areas
# Load site prioritaire ap and harmonized variables
prioritaire_ap <- vect("./data/source/pa_history_mdg/sapm_evolution_2012/commondata/data1/site_prioritaire_ap.shp") %>%
  mutate(
    WDPAID = as.integer(paste0("666000", row_number())),
    NAME = paste0("Prioritaire_", row_number()),
    DESIG = "Prioritaire AP",
    MANG_AUTH = "Prioritaire AP",
    IUCN_CAT = "Prioritaire AP",
    STATUS = "Prioritaire AP",
    STATUS_YR_DYN = 2026,
    zone_type = "external_boundary"
  ) %>%
  select(WDPAID, NAME, DESIG, MANG_AUTH, IUCN_CAT, STATUS, STATUS_YR_DYN, zone_type) %>%
  project(dynamic_wdpa_vect)

dynamic_pa_vect <- rbind(dynamic_wdpa_vect, prioritaire_ap)

dynamic_pa_metadata <- dynamic_pa_vect %>%
  as.data.frame() %>%
  # Remove core
  dplyr::filter(zone_type == "external_boundary") %>%
  group_by(WDPAID) %>%
  mutate(
    STATUS_YR = min(STATUS_YR_DYN, na.rm = TRUE),
    STATUS_YR_WDPA = max(STATUS_YR_DYN),
    STATUS_YR_PERM = min(STATUS_YR_DYN[DESIG != "Protection Temporaire"])
  ) %>%
  ungroup() %>%
  arrange(WDPAID, STATUS_YR) %>%
  group_by(WDPAID) %>%
  slice_tail(n=1) %>%
  ungroup() %>%
  mutate(
    STATUS_YR_PERM = ifelse(is.infinite(STATUS_YR_PERM), 2026, STATUS_YR_PERM),
    # For those without websites, IUCN_CAT is based on status (Décret 2015-005)
    # Paysage Harmonieux protégée = V
    # Réserve naturelle = IV
    # Parc naturel = II
    IUCN_CAT = case_when(
      WDPAID == 352239 ~ "IV",  # Analamerana (RS)
      WDPAID == 555547961 ~ "V", # Mandrozo (PHP): FAPBM.org/aire_protegee/mandrozo
      WDPAID == 555697872 ~ "VI", # Antrema (RRN): ProtectedPlanet.net/555697872
      WDPAID == 555697914 ~ "V", # Bombetoka Beloboka (PHP): FAPBM.org/aire_protegee/bombetoka
      WDPAID == 555697915 ~ "V", # Ambohidray (PHP): mbev.univ-antananarivo.mg/Ambohidray.php
      WDPAID == 555697916 ~ "V", # Ambararata Londa (PHP)
      WDPAID == 555549449 ~ "V", # Vohidefo (PHP)
      WDPAID == 555549450 ~ "V", # Angavo (PHP)
      WDPAID == 555549451 ~ "V", # Behara-Tranomaro (PHP)
      WDPAID == 555549452 ~ "V", # Sud-Ouest Ifotaky (PHP)
      WDPAID == 555549460 ~ "V", # Ranobe PK 32 (PHP)
      WDPAID == 555697871 ~ "II", # Ambohimirahavavy Marivorahona (PN)
      WDPAID == 555790172 ~ "V", # Ankafobe (PHP)
      WDPAID == 555790168 ~ "Protection temporaire", # Tsinjoarivo Ambalaomby, still temporary
      STATUS == "Proposed" ~ "Proposed AP",
      TRUE ~ IUCN_CAT
    ),
    SHORT_NAME = case_match(NAME,
                            "Betampona"                                              ~ "Betampona",
                            "Tsimanampesotse"                                        ~ "Tsimanampe",
                            "Befotaka Midongy"                                       ~ "Befotaka",
                            "Isalo"                                                  ~ "Isalo",
                            "Mantadia"                                               ~ "Mantadia",
                            "Mananara Nord"                                          ~ "Mananara",
                            "Ranomafana"                                             ~ "Ranomafana",
                            "Tsaratanana"                                            ~ "Tsarata.",
                            "Masoala"                                                ~ "Masoala",
                            "Baie de Baly"                                           ~ "Baie Baly",
                            "Bemaraha"                                               ~ "Bemaraha",
                            "Marojejy"                                               ~ "Marojejy",
                            "Andringitra"                                            ~ "Andringi.",
                            "Namoroka"                                               ~ "Namoroka",
                            "Mikea"                                                  ~ "Mikea",
                            "Makira"                                                 ~ "Makira",
                            "Ankarafantsika"                                         ~ "Ankaraf.",
                            "Andohahela"                                             ~ "Andohahela",
                            "Montagne d'Ambre"                                       ~ "Mont Ambre",
                            "Analamazaotra"                                          ~ "Analamaz.",
                            "Analamerana"                                            ~ "Analamer.",
                            "Zombitse Vohibasia"                                     ~ "Zombitse",
                            "Zahamena"                                               ~ "Zahamena",
                            "Complexe des lacs Ambondro et Sirave (CLAS)"            ~ "CLAS Lakes",
                            "Marolambo"                                              ~ "Marolambo",
                            "Zones Humides Ankarafantsika  (CLSA)"                   ~ "CLSA Ank.",
                            "Analavelona"                                            ~ "Analavelon",
                            "Allées des Baobabs"                                     ~ "Baobabs",
                            "Bemarivo"                                               ~ "Bemarivo",
                            "Bora"                                                   ~ "Bora",
                            "Kasijy"                                                 ~ "Kasijy",
                            "Maningoza"                                              ~ "Maningoza",
                            "Ambohijanahary"                                         ~ "Ambohijan.",
                            "Ambatovaky"                                             ~ "Ambatovaky",
                            "Mangerivola"                                            ~ "Mangeri.",
                            "Kalambatrika"                                           ~ "Kalamba.",
                            "Tampoketsa Analamaitso"                                 ~ "Tampoketsa",
                            "Manombo"                                                ~ "Manombo",
                            "Ivohibe"                                                ~ "Ivohibe",
                            "Ambohitantely"                                          ~ "Ambohita.",
                            "Beza Mahafaly"                                          ~ "Beza Maha.",
                            "Le Lac Alaotra : Les Zones Humides et Bassins Versants" ~ "Lac Alaotra",
                            "Anjanaharibe_sud"                                       ~ "Anjanaha.",
                            "Ankarana"                                               ~ "Ankarana",
                            "Manongarivo"                                            ~ "Manongari.",
                            "Marotandrano"                                           ~ "Marotandra",
                            "Nosy Mangabe"                                           ~ "Nosy Manga",
                            "Andranomena"                                            ~ "Andranome.",
                            "Cap Sainte Marie"                                       ~ "Cap Ste Ma",
                            "Analalava"                                              ~ "Analalava",
                            "Réserve spéciale Pointe à Larrée"                       ~ "Pte Larree",
                            "Kinkony Lake"                                           ~ "Kinkony Lk",
                            "Site Bioculturel d'Antrema"                             ~ "Antrema",
                            "Complexe Tsimembo Manambolomaty"                        ~ "Tsimembo",
                            "Parc Alarobia"                                          ~ "Alarobia",
                            "Zones humides de Bedo"                                  ~ "Bedo",
                            "Rivière Nosivolo et affluents"                          ~ "Nosivo Af",
                            "Lac Mandrozo"                                           ~ "Mandrozo",
                            "Complexe Anjozorobe Angavo"                             ~ "Anjozorobe",
                            "Ankodida"                                               ~ "Ankodida",
                            "Corridor forestier Bongolava"                           ~ "Bongolava",
                            "Nord fotaky"                                            ~ "Fotaky",
                            "Mandena"                                                ~ "Mandena",
                            "Menabe Antimena"                                        ~ "Menabe Ant",
                            "Ambohitr'Antsingy Montagne des Français"                ~ "Mont Franc",
                            "Amoron'i Onilahy"                                       ~ "Amoro Onil",
                            "Ambatoatsinanana"                                       ~ "Ambatoatsi",
                            "Réserve de Tampolo"                                     ~ "Tampolo",
                            "Rivière Nosivolo"                                       ~ "Nosivolo",
                            "Complexe Lac Forêt Ambondrobe"                          ~ "Lac Ambond.",
                            "Complexe Zones Humides Mangoky Ihotry"                  ~ "Mangoky",
                            "Beanka"                                                 ~ "Beanka",
                            "Sahafina"                                               ~ "Sahafina",
                            "Corridor Forestier Ambositra Vondrozo"                  ~ "Ambositra",
                            "Massif d'Itremo"                                        ~ "Itremo",
                            "Ambatofotsy"                                            ~ "Ambatofo.",
                            "Ampotaka Ankorabe"                                      ~ "Ampotaka",
                            "Ampanganandehibe-Behasina"                              ~ "Ampanga.",
                            "Ampasindava"                                            ~ "Ampasindav",
                            "Galoko Kalobinono"                                      ~ "Galoko Kal",
                            "Oronjia"                                                ~ "Oronjia",
                            "Massif d'Ibity"                                         ~ "Ibity",
                            "Forêt Naturel de Petriky"                               ~ "Petriky",
                            "Andreba"                                                ~ "Andreba",
                            "COMATSA Sud"                                            ~ "COMATSA S",
                            "Bemanevika"                                             ~ "Bemanevika",
                            "Loky Manambato"                                         ~ "Loky Manam",
                            "Andrafiamena Andavakoera"                               ~ "Andrafiame",
                            "Complexe des Zones Humides de Bemanevika"               ~ "ZH Bemane.",
                            "Zones humides de l'Onilahy"                             ~ "Onilahy",
                            "Anjajavy"                                               ~ "Anjajavy",
                            "Ivohiboro"                                              ~ "Ivohiboro",
                            "Corridor Ankeniheny Zahamena"                           ~ "Ankeniheny",
                            "Forêt Naturelle de Tsitongambarika"                     ~ "Tsitongamb",
                            "Maromizaha"                                             ~ "Maromizaha",
                            "Mangabe-Ranomena-Sahasarotra"                           ~ "Mangabe",
                            "Analabe-Betanatanana"                                   ~ "Analabe",
                            "Agnalazaha"                                             ~ "Agnalazaha",
                            "Makirovana Tsihomanaomby"                               ~ "Makirovana",
                            "Vohidava Betsimalao"                                    ~ "Vohidava",
                            "Ankarabolava"                                           ~ "Ankarabola",
                            "Agnakatrika"                                            ~ "Agnakatri.",
                            "Mahimborondro"                                          ~ "Mahimboron",
                            "COMATSA Nord"                                           ~ "COMATSA N",
                            "Manjakatompo Ankaratra"                                 ~ "Ankaratra",
                            "Zones humides d'Ambondrobe"                             ~ "ZH Ambond.",
                            "Parc national Tsimanampesotse"                          ~ "PN Tsimana",
                            "Torotorofotsy"                                          ~ "Torotorofo",
                            "Ambatotsirongorongo"                                    ~ "Ambatotsir",
                            "Vohidefo"                                               ~ "Vohidefo",
                            "Angavo"                                                 ~ "Angavo",
                            "Behara-Tranomaro"                                       ~ "Behara",
                            "Sud-Ouest Ifotaky"                                      ~ "Ifotaky",
                            "Ranobe PK 32"                                           ~ "Ranobe",
                            "Ambohidray"                                             ~ "Ambohidray",
                            "Ambararata Londa"                                       ~ "Ambararata",
                            "Vohimana"                                               ~ "Vohimana",
                            "Madiro Mirafy"                                          ~ "Madiro Mir",
                            "APC Miary"                                              ~ "APC Miary",
                            "Makay"                                                  ~ "Makay",
                            "Lac Sofia"                                              ~ "Lac Sofia",
                            "Ankafobe"                                               ~ "Ankafobe",
                            "APC Vezo"                                               ~ "APC Vezo",
                            "Beampingaratsy"                                         ~ "Beampinga.",
                            "Ankirihitra"                                            ~ "Ankirihi.",
                            "APC Agnala"                                             ~ "APC Agnala",
                            "APC Loharano"                                           ~ "APC Lohara",
                            "APC Lovasoa"                                            ~ "APC Lovaso",
                            "APC Mikea Mitambatra"                                   ~ "APC Mikea",
                            "Tsinjoarivo Ambalaomby"                                 ~ "Tsinjoariv",
                            "Complexe Bobaomby"                                      ~ "Bobaomby",
                            "Complexe des  AP Ambohimirahavavy Marivorahona"         ~ "Ambohimira",
                            "Andrefana Dry Forests"                                  ~ "Andrefana",
                            "Forêts humides de l’Atsinanana"                         ~ "Atsinanana",
                            "Kirindy Mite"                                           ~ "Kirindy M",
                            "Sahamalaza Iles Radama"                                 ~ "Sahamalaza",
                            "Lokobe"                                                 ~ "Lokobe",
                            "Complexe Zones Humides Mahavavy Kinkony"                ~ "Mahavavy K",
                            "Nosy Antsoha"                                           ~ "Nosy Antso",
                            "Tsinjoriake"                                            ~ "Tsinjoriak",
                            "Mangroves de Tsiribihina"                               ~ "Tsiribihi.",
                            "Bombetoka Beloboka"                                     ~ "Bombetoka",
                            "Ankingabe"                                              ~ "Ankingabe",
                            "Mangroves de la Baie d'Ambaro"                          ~ "Ambaro",
                            "Le Lac Alaotra: les zones humides et basin" ~ "Aloatra ZH",
                            "Parc de Tsarasaotra"                                    ~ "Tsarasaotra",
                            "Rainforests of the Atsinanana"                          ~ "Atsinanana",
                            "Lac Kinkony" ~ "Kinkony",
                            "Mandrozo" ~ "Mandrozo",
                            "Zones Humides de Sahamalaza" ~ "Sahamalaza",
                            "Lac Alaotra" ~ "Alaotra",
                            "Mahialambo" ~ "Mahialambo",
                            .default = NAME
    )) %>%
  mutate(
    MANAGER = case_when(
      MANG_AUTH %in% c("Ministry of Environment and Sustainable Development", "Not Reported") ~ "Not Reported",
      MANG_AUTH %in% c("Ministry of Environment and Sustainable Development, MNP", "Madagascar National Parks", "Adresse 1: Madagascar National Parks Lot AI 10C Ambatobe Antananarivo (101)\nAdresse 2: Madagascar National Parks Ankarafantsika Ampijoroanala RN4 Marovay (416)", "Direction de MNP (Toliara)") ~ "Madagascar National Parks",
      MANG_AUTH %in% c("Ministry of Environment and Sustainable Development, DURRELL", "DURRELL  lot II Y 39 J Ampasanimalo, 101 Antananrivo Madagascar\n DURRELL  lot 14433 Avaradrova Immeuble CECAM AMBATONDRAZAKA, Région Alaotra Mangoro, Madagascar", "Durrell Wildlife Conservation Trust, Programme Madagascar", "Durrell Wildlife Conservation Trust - Madagascar", "DURRELL Madagascar") ~ "Durrell Wildlife Conservation Trust",
      MANG_AUTH %in% c("Ministry of Environment and Sustainable Development, FANAMBY", "ONG FANAMBY") ~ "Association Fanamby",
      MANG_AUTH %in% c("Ministry of Environment and Sustainable Development, WWF", "WWF MDCO") ~ "World Wide Fund for Nature",
      MANG_AUTH %in% c("Ministry of Environment and Sustainable Development, TPF", "The Peregrine Fund") ~ "The Peregrine Fund",
      MANG_AUTH %in% c("Ministry of Environment and Sustainable Development, MAVOA", "Ministry of Environment and Sustainable Development,MAVOA") ~ "Association Mavoa",
      MANG_AUTH %in% c("Ministry of Environment and Sustainable Development, LEMURIA LAND", "Ministry of Environment and Sustainable Development, Lemuria Land") ~ "Lemuria Land",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, MBG" ~ "Missouri Botanical Garden",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, WCS" ~ "Wildlife Conservation Society",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, VELONALA Association" ~ "Association Velonala",
      MANG_AUTH == "Site Bioculturel d'Antrema\nAntananarivo" ~ "Museum National d'Histoire Naturelle",
      MANG_AUTH == "Association Parc Tsarasaotra (APT)" ~ "Association Parc Tsarasaotra",
      MANG_AUTH == "Plate-forme de gestion « Filongoa Mandrozo » avec trois COBAs (Communauté Locale de Base) : ZAMAMI, FIVOMA et FIMITOVE." ~ "The Peregrine Fund",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, FBM" ~ "Fikambanana Bongolava Maitso",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, QMM" ~ "QIT Madagascar Minerals",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, SAGE" ~ "Service d'Appui à la Gestion de l'Environnement",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, ESSA FOREST" ~ "Ecole Supérieure des Sciences Agronomiques - Forêts",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, ASITY Mcar" ~ "Asity Madagascar",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, BCM" ~ "Biodiversity Conservation Madagascar",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, THIS" ~ "Conservation International",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, RBG KEW" ~ "Royal Botanic Gardens, Kew",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, FAMELONA Association" ~ "Association Famelona",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, Anjajavy Lodge" ~ "Anjajavy Lodge",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, MICET" ~ "Madagascar Institute for the Conservation of Tropical Environments",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, GERP" ~ "Groupe d'Étude et de Recherche sur les Primates de Madagascar",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, LIVELY" ~ "Association Lively",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, MNHN" ~ "Museum National d'Histoire Naturelle",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, DBEV" ~ "Département de Biologie et Écologie Végétales",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, Man and the Environment" ~ "Man and the Environment",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, Impact Madagascar" ~ "Impact Madagascar",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, Malagasy Miarony Natiora" ~ "Malagasy Miarony Natiora",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, NITIDEA" ~ "Nitidae",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, NGO SADABE" ~ "NGO Sadabe",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, CI" ~ "Conservation International",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, Blue Ventures" ~ "Blue Ventures",
      MANG_AUTH == "Blue Ventures Madagascar / WWF MDCO" ~ "Blue Ventures / World Wide Fund for Nature",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, TAMIA Association" ~ "Association Tamia",
      MANG_AUTH == "Ministry of Environment and Sustainable Development, DELC" ~ "Development and Environmental Law Center",
      TRUE ~ MANG_AUTH
    ),
    MANAGER_SHORT = case_when(
      MANAGER == "Not Reported" ~ "Not Reported",
      MANAGER == "Madagascar National Parks" ~ "MNP",
      MANAGER == "Missouri Botanical Garden" ~ "MBG",
      MANAGER == "Association Fanamby" ~ "Fanamby",
      MANAGER == "Wildlife Conservation Society" ~ "WCS",
      MANAGER == "Durrell Wildlife Conservation Trust" ~ "Durell",
      MANAGER == "Association Velonala" ~ "Velonal",
      MANAGER == "Site Bioculturel d'Antrema" ~ "SBA",
      MANAGER == "Association Parc Tsarasaotra" ~ "APT",
      MANAGER == "Plate-forme de gestion Filongoa Mandrozo" ~ "PFGM",
      MANAGER == "World Wide Fund for Nature" ~ "WWF",
      MANAGER == "Fikambanana Bongolava Maitso" ~ "FBM",
      MANAGER == "QIT Madagascar Minerals" ~ "QMM",
      MANAGER == "Service d'Appui à la Gestion de l'Environnement" ~ "SAGE",
      MANAGER == "Ecole Supérieure des Sciences Agronomiques - Forêts" ~ "ESSA-Forêts",
      MANAGER == "Asity Madagascar" ~ "ASITY",
      MANAGER == "Biodiversity Conservation Madagascar" ~ "BCM",
      MANAGER == "Royal Botanic Gardens, Kew" ~ "RBG Kew",
      MANAGER == "Association Mavoa" ~ "MAVOA",
      MANAGER == "Association Famelona" ~ "FAMELONA",
      MANAGER == "The Peregrine Fund" ~ "TPF",
      MANAGER == "Anjajavy Lodge" ~ "Anjajavy",
      MANAGER == "Madagascar Institute for the Conservation of Tropical Environments" ~ "MICET",
      MANAGER == "Groupe d'Étude et de Recherche sur les Primates de Madagascar" ~ "GERP",
      MANAGER == "Association Lively" ~ "LIVELY",
      MANAGER == "Museum National d'Histoire Naturelle" ~ "MNHN",
      MANAGER == "Département de Biologie et Écologie Végétales" ~ "DBEV",
      MANAGER == "Man and the Environment" ~ "MATE",
      MANAGER == "Impact Madagascar" ~ "IM",
      MANAGER == "Malagasy Miarony Natiora" ~ "MMN",
      MANAGER == "Nitidae" ~ "NITIDAE",
      MANAGER == "NGO Sadabe" ~ "SADABE",
      MANAGER == "Conservation International" ~ "CI",
      MANAGER == "Blue Ventures" ~ "BV",
      MANAGER == "Blue Ventures / World Wide Fund for Nature" ~ "BV/WWF",
      MANAGER == "Lemuria Land" ~ "LEMURIA",
      MANAGER == "Association Tamia" ~ "TAMIA",
      MANAGER == "Development and Environmental Law Center" ~ "DELC",
      TRUE ~ MANAGER
    ),
    MANAGER_TYPE = case_when(
      MANAGER_SHORT == "MNP" ~ "MNP",
      MANAGER_SHORT %in% c("MBG", "WCS", "Durell", "WWF", "RBG Kew", "TPF", "MNHN", "NITIDAE", "CI", "BV", "BV/WWF", "SADABE") ~ "International ONG",
      MANAGER_SHORT %in% c("Fanamby", "Velonal", "SBA", "APT", "PFGM", "FBM", "SAGE", "ASITY", "BCM", "MAVOA", "FAMELONA", "MICET", "GERP", "LIVELY", "MATE", "IM", "MMN", "TAMIA", "DELC", "QMM", "ESSA-Forêts", "Anjajavy", "DBEV", "LEMURIA") ~ "Local ONG",
      TRUE ~ NA_character_
    )
  ) %>%
  select(
    WDPAID, NAME, SHORT_NAME, DESIG, IUCN_CAT, STATUS,
    STATUS_YR, STATUS_YR_PERM, STATUS_YR_WDPA,
    MANG_AUTH, MANAGER, MANAGER_SHORT, MANAGER_TYPE
  )
print(dynamic_pa_metadata)


# Export metadata of WDPA
write.csv(dynamic_pa_metadata, "data/source/WDPA_data/dynamic_pa_metadata.csv", row.names = FALSE)

# put to s3
map2(
  paste0("data/source/WDPA_data/dynamic_pa_metadata.csv"),
  paste0(data_dest, "/WDPA_data/dynamic_pa_metadata.csv"),
  put_to_s3
)


### Database with fixed boundaries

### Take last boundary
dynamic_pa_last <- dynamic_pa_vect %>%
  dplyr::filter(zone_type == "external_boundary") %>%
  select(WDPAID) %>%
  group_by(WDPAID) %>%
  slice_tail(n = 1) %>%
  ungroup() %>%
  mutate(PA_AREA_KM2 = expanse(., unit="km"))

#Export the cleaned data
writeVector(
  dynamic_pa_last,
  filename = "data/source/WDPA_data/dynamic_pa_fixed_last.gpkg",
  overwrite = TRUE
)
# put to s3
map2(
  paste0("data/source/WDPA_data/dynamic_pa_fixed_last.gpkg"),
  paste0(data_dest, "/WDPA_data/dynamic_pa_fixed_last.gpkg"),
  put_to_s3
)


### Take intersection boundary
dynamic_pa_intersec <- pblapply(
  unique(dynamic_pa_vect$WDPAID), 
  function(id) {
    sub <- dynamic_pa_vect %>%
      filter(zone_type == "external_boundary") %>%
      filter(WDPAID == id) %>%
      select(WDPAID)
    # Intersect all polygons in the group iteratively
    if (nrow(sub)>=2) {
      inter <- sub[1, ]
      for (i in seq(2, nrow(sub))) {
        inter <- intersect(inter, sub[i, ])
      }
    } else {
      inter <- sub
    }
    inter$WDPAID = id
    inter %>% select(WDPAID)
  }) %>%
  bind_spat_rows() %>%
  mutate(PA_AREA_KM2 = expanse(., unit="km"))

#Export the cleaned data
writeVector(
  dynamic_pa_intersec,
  filename = "data/source/WDPA_data/dynamic_pa_fixed_intersec.gpkg",
  overwrite = TRUE
)
# put to s3
map2(
  paste0("data/source/WDPA_data/dynamic_pa_fixed_intersec.gpkg"),
  paste0(data_dest, "/WDPA_data/dynamic_pa_fixed_intersec.gpkg"),
  put_to_s3
)


### Core zone

# Take last boundary : several frontier exsit but there are all equivalent
core_pa_last <- dynamic_pa_vect %>%
  dplyr::filter(zone_type == "secondary_zoning") %>%
  select(WDPAID) %>%
  group_by(WDPAID) %>%
  slice_tail(n = 1) %>%
  ungroup() %>%
  mutate(CORE_AREA_KM2 = expanse(., unit="km")) %>%
  # Remove the core with area of e-9
  filter(CORE_AREA_KM2 >= 0.01)

#Export the cleaned data
writeVector(
  core_pa_last,
  filename = "data/source/WDPA_data/core_pa.gpkg",
  overwrite = TRUE
)
# put to s3
map2(
  paste0("data/source/WDPA_data/core_pa.gpkg"),
  paste0(data_dest, "/WDPA_data/core_pa.gpkg"),
  put_to_s3
)